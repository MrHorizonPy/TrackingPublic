import json
import requests
import glob
import pythoncom
from bs4 import BeautifulSoup
import win32com.client as client
from mailmerge import MailMerge
from docx import Document
import customtkinter as ctk
import threading
import os
from docx2pdf import convert

class GUI:
    def __init__(self,master):
        custom_font = ("Arial", 15, "bold")

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self.frame_left = ctk.CTkFrame(master,height=500,width=210)
        self.frame_left.pack(padx=10,pady=10,side="left")
        self.frame_right = ctk.CTkFrame(master,height=500,width=550)
        self.frame_right.pack(padx=10,pady=10,side="right")

        self.track_label = ctk.CTkLabel(self.frame_left,text="Insert Tracking Numbers:",text_color="gray")
        self.track_label.place(x=10,y=10)
        self.track_entry = ctk.CTkTextbox(self.frame_left,width=190,height=400,text_color="white")
        self.track_entry.place(x=10,y=45)

        self.start_button = ctk.CTkButton(self.frame_left,text="Start",width=190,fg_color="#0575E4",font=custom_font,command=lambda:start(self))
        self.start_button.place(x=10,y=460)

        self.track_out_label = ctk.CTkLabel(self.frame_right,text="Tracking Results:",text_color="gray")
        self.track_out_label.place(x=20,y=10)

        self.track_out = ctk.CTkTextbox(self.frame_right,width=515,height=400,text_color="white",font=("Arial",12))
        self.track_out.place(x=20,y=45)
        self.track_out.configure(state="disabled")

        self.open_folder = ctk.CTkButton(self.frame_right,text="Open Folder",width=515,fg_color="#0575E4",font=custom_font,command="")
        self.open_folder.place(x=20,y=460)

def start(gui):
    numbers = gui.track_entry.get("1.0","end-1c")
    stato = "In lavorazione"
    if not numbers == "":
        gui.start_button.configure(state="disabled")
        gui.track_entry.configure(state="disabled")
        gui.track_out.configure(state="normal")
        gui.track_out.delete("1.0","end-1c")
        gui.track_out.configure(state="disabled")

        numbers_list = numbers.split("\n")

        login_url = 'https://liccardi.spedisci.online/login'
        tracking_url = "https://liccardi.spedisci.online/tracking/"

        headers = {
            'authority': 'liccardi.spedisci.online',
            'cache-control': 'max-age=0',
            'origin': 'https://liccardi.spedisci.online',
            'user-agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0',
            'accept': 'image/avif,image/webp,*/*',
            'referer' : 'https://liccardi.spedisci.online/login',
            'accept-language': 'en-US,en;q=0.5'
        }

        data = {
            '_token': '-empty-',
            'email': 'pitermenna17@gmail.com',
            'password': 'GigiFiorentino@0'
        }

        with requests.Session() as s:
            response = s.get(login_url,headers=headers)

            soup = BeautifulSoup(response.text,features="lxml")
            token = soup.find('input', {'name': "_token"})['value']
            data['_token'] = token

            response = s.post(login_url,data=data,headers=headers)

            pythoncom.CoInitialize()
            word = client.Dispatch("Word.Application")

            for number in numbers_list: 
                response = s.get(tracking_url + number,headers=headers)
                data = json.loads(response.text)

                dataSp = data["tracking"]["dataSp"]

                i = 0
                for dettaglio in data["TrackingDettaglio"]:
                    locals()["tracking%s" % i] = dettaglio
                    i += 1
                nominativo = data["shipping"]["nominativo"]
                indirizzo = data["shipping"]["indirizzo"]
                tel_dest = data["shipping"]["tel_dest"]
                email_dest = data["shipping"]["email_dest"]
                order_number = data["shipping"]["order_number"]
                note = data["shipping"]["note"]

                gui.track_out.configure(state="normal")
                
                if number == str(gui.track_entry.get("0.0","0.end")):
                    gui.track_out.insert("end","====================================================================")
                gui.track_out.insert("end",f"\nTracking Number: {number}\n")
                gui.track_out.insert("end",f"\nData Spedizione:\n{dataSp}\n")
                gui.track_out.insert("end",f"\nDestinatario:\n {nominativo}\n{indirizzo}\n")
                gui.track_out.insert("end",f"\nTelefono Destinatario:\n{tel_dest}\n")
                gui.track_out.insert("end",f"\nEmail Destinatario:\n{email_dest}\n")
                gui.track_out.insert("end",f"\nNumero Ordine:\n{order_number}\n")
                gui.track_out.insert("end",f"\nNote:\n{note}\n")
                gui.track_out.insert("end","\n--------------------STORICO TRACKING--------------------")
                
                for _ in range(i):
                    gui.track_out.insert("end","\nSTATO: " + locals()["tracking%s" % _]["Data"] + " " + locals()["tracking%s" % _]["Stato"] + " " + locals()["tracking%s" % _]["Luogo"] + "\n")
                    if "DATI SPEDIZIONE TRASMESSI A LICCARDI" in locals()["tracking%s" % _]["Stato"]:
                        stato = "In lavorazione"
                    elif "SPEDIZIONE RITIRATA" in locals()["tracking%s" % _]["Stato"]:
                        stato = "Spedita"
                    elif "SPEDIZIONE PARTITA" in locals()["tracking%s" % _]["Stato"]:
                        stato = "In transito"
                    elif "IN GIACENZA" in locals()["tracking%s" % _]["Stato"]:
                        stato = "In giacenza"
                    elif "RESO AL MITTENTE" in locals()["tracking%s" % _]["Stato"]:
                        stato = "Reso al mittente"
                    elif "IN CONSEGNA" in locals()["tracking%s" % _]["Stato"]:
                        stato = "In consegna"
                    elif "SPEDIZIONE CONSEGNATA" in locals()["tracking%s" % _]["Stato"]:
                        stato = "Consegnata"

                gui.track_out.insert("end","-----------------------------------------------------------------------------\n")
                gui.track_out.insert("end","====================================================================\n")
                
                pdf_compiler(dataSp,nominativo,indirizzo,tel_dest,email_dest,order_number,note,stato,number)
                
        files = [f for f in glob.glob("**/*.docx") if 'Template.docx' not in f]

        threads = []
        for file in files:
            word_id = pythoncom.CoMarshalInterThreadInterfaceInStream(pythoncom.IID_IDispatch,word)
            thread = threading.Thread(target=convert_to_pdf,args=(file,word))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join()

        word.quit()
        gui.start_button.configure(state="normal")
        gui.track_entry.configure(state="normal")
        gui.track_out.configure(state="disabled")

def run():
    root = ctk.CTk()
    root.geometry("800x520")
    root.title("Tracker_Reporter")
    root.resizable(False,False)
    gui = GUI(root)
    root.mainloop()

def pdf_compiler(dataSp,nominativo,indirizzo_sp,tel_dest,email_dest,order_number,note_sp,stato_sp,number):
    template = "Template/Template.docx"
    document = MailMerge(template)
    document.merge(
        data = dataSp,
        nome = nominativo,
        indirizzo = indirizzo_sp,
        tel = tel_dest,
        email_doc = email_dest,
        order_n = order_number,
        note = note_sp,
        stato = stato_sp,
        tracking = number
    )

    filename = "Report_Spedizione_" + number
    document.write("REPORTs/"+ filename + ".docx")
    doc = Document("REPORTs/"+ filename + ".docx")
    doc.save("REPORTs/"+ filename + ".docx")
    
def convert_to_pdf(file,word):
    word.Visible = False
    file = os.path.abspath(file)
    out_file = file.replace(".docx",".pdf").replace(".doc",".pdf")
    doc = word.Documents.Open(file)
    doc.SaveAs(out_file, FileFormat=17)
    doc.Close()

if __name__ == "__main__":
    run()