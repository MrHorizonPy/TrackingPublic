from cx_Freeze import setup, Executable

setup(
    name="SHIPs_Reporter",
    version="1.0",
    description="",
    executables=[Executable("txt_to_csv.py", base="Win32GUI", icon=r"C:\Users\vsignore\Downloads\csv_icon_213593.ico")]
)