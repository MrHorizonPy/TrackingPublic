from customtkinter import filedialog
from datetime import datetime
import customtkinter as ctk
import pandas as pd
import time
import json
import csv
import os

class GUI:
    def __init__(self,master):
        self.main_frame = ctk.CTkFrame(master,height=200,width=500)
        self.main_frame.pack(padx=10,pady=10)

        self.browse_label = ctk.CTkLabel(self.main_frame,text="File directory:",text_color="gray",font=("Arial",12,"bold"))
        self.browse_label.place(x=10,y=10)

        self.browse_TextBox = ctk.CTkTextbox(self.main_frame,width=370,height=12,state="disabled",font=("Arial",11,"bold"))
        self.browse_TextBox.place(x=10,y=38)

        self.browse_button = ctk.CTkButton(self.main_frame,text="Browse",font=("Arial",12,"bold"),width=80,command=lambda:select_file(self))
        self.browse_button.place(x=390,y=38)

        self.report_button = ctk.CTkButton(self.main_frame,text="Genera Report",font=("Arial",12,"bold"),width=120,command=lambda:report(self,True))
        self.report_button.place(x=10,y=80)

        self.report_button2 = ctk.CTkButton(self.main_frame,text="Genera Report con ITEM-ID",font=("Arial",12,"bold"),width=140,command=lambda:report(self,False))
        self.report_button2.place(x=140,y=80)

def report(gui,control):
    file = gui.browse_TextBox.get("1.0","1.end")
    txt_file = pd.read_csv(file, delimiter = "\t", engine = "python")

    csv_file = file.replace(".txt",".csv")
    txt_file.to_csv(csv_file, index=False, quoting=csv.QUOTE_NONNUMERIC)

    reader = csv.DictReader(open(csv_file))

    with open("TEMPLATEs/comuni.json", "r", encoding="utf-8") as file:
        comuni_data = json.load(file)

    if control == True:
        with open("TEMPLATEs/Template1.csv", "r") as template_file:
            template_reader = csv.reader(template_file)
            header = next(template_reader)
    else:
        with open("TEMPLATEs/Template2.csv", "r") as template_file:
            template_reader = csv.reader(template_file)
            header = next(template_reader)     

    date = datetime.today().strftime('%d-%m-%Y-%H%M')
    if control == True:
        with open(f"REPORTs/Report_{date}.csv", "w", newline = "") as output_file:
            writer = csv.writer(output_file)
            writer.writerow(header)
    else:
        with open(f"REPORTs/ReportConID_{date}.csv", "w", newline = "") as output_file:
            writer = csv.writer(output_file)
            writer.writerow(header)        

    for raw in reader:
        buyer_name = raw["recipient-name"]
        buyer_name = remove_non_ascii(buyer_name)

        ship_address = raw["ship-address-1"]
        if raw["ship-address-2"] != "":
            ship_address = ship_address + "\n" + raw["ship-address-2"]
        if raw["ship-address-3"] != "":
            ship_address = ship_address + "\n" + raw["ship-address-3"]
        ship_address = remove_non_ascii(ship_address)

        cap = raw["ship-postal-code"]
        if len(cap) == 4:
            cap = "0" + cap
        elif len(cap) == 3:
            cap = "00" + cap
        elif len(cap) == 2:
            cap = "000" + cap

        City = raw["ship-city"]
        City = remove_non_ascii(City)

        for comune in comuni_data:
            if cap in comune["cap"]:
                province = comune["sigla"]
                break
        quantity = raw["quantity-purchased"]

        note = f"QTY {quantity} " + raw["product-name"]
        note = remove_non_ascii(note)

        tel = raw["buyer-phone-number"]
        order_id = raw["order-id"]

        if control == False:
            order_item_id = raw["order-item-id"]
            order_item_id = remove_non_ascii(order_item_id)

            with open(f"REPORTs/ReportConID_{date}.csv", "a", newline = "") as output_file:
                writer = csv.writer(output_file,quoting=csv.QUOTE_ALL)
                writer.writerow([buyer_name,ship_address,cap,City,province,"1","1","","Fiorentino Service","",note,tel,"","",order_id,"",order_item_id])
        else:
            with open(f"REPORTs/Report_{date}.csv", "a", newline = "") as output_file:
                writer = csv.writer(output_file,quoting=csv.QUOTE_ALL)
                writer.writerow([buyer_name,ship_address,cap,City,province,"1","1","","Fiorentino Service","",note,tel,"","",order_id,""])
    del(reader)
    os.remove(csv_file)

def select_file(gui):
    file = filedialog.askopenfilename()
    if file != "":
        gui.browse_TextBox.configure(state="normal")
        gui.browse_TextBox.delete("1.0","end")
        gui.browse_TextBox.insert("1.0",file)
        gui.browse_TextBox.configure(state="disabled")
    

def remove_non_ascii(string):
    return "".join(i for i in string if ord(i)<128)

def run():
    root = ctk.CTk()
    root.geometry("500x140")
    root.title("SHIPs_Reporter")
    root.resizable(False,False)
    gui = GUI(root)
    root.mainloop()

if __name__ == "__main__":
    run()