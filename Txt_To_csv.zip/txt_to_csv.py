import pandas as pd
import json
import csv
import os

def main():
    txt_file = pd.read_csv("81494564816019787.txt", delimiter = "\t", engine = "python")
    txt_file.to_csv("81494564816019787.csv", index = None)


    reader = csv.DictReader(open("81494564816019787.csv"))

    with open("comuni.json", "r", encoding="utf-8") as file:
        comuni_data = json.load(file)

    with open("Template.csv", "r") as template_file:
        template_reader = csv.reader(template_file)
        header = next(template_reader)

    with open("Resoconto.csv", "w", newline = "") as output_file:
        writer = csv.writer(output_file)
        writer.writerow(header)

    for raw in reader:
        buyer_name = raw["recipient-name"]
        buyer_name = remove_non_ascii(buyer_name)

        ship_address = raw["ship-address-1"]
        if raw["ship-address-2"] != "":
            ship_address = ship_address + "\n" + raw["ship-address-2"]
        if raw["ship-address-3"] != "":
            ship_address = ship_address + "\n" + raw["ship-address-3"]
        ship_address = remove_non_ascii(ship_address)

        cap = raw["ship-postal-code"]
        if len(cap) == 4:
            cap = "0" + cap
        elif len(cap) == 3:
            cap = "00" + cap
        elif len(cap) == 2:
            cap = "000" + cap

        City = raw["ship-city"]
        City = remove_non_ascii(City)

        for comune in comuni_data:
            if cap in comune["cap"]:
                province = comune["sigla"]
                break
        quantity = raw["quantity-purchased"]

        note = f"QTY {quantity} " + raw["product-name"]
        note = remove_non_ascii(note)

        tel = raw["buyer-phone-number"]
        order_id = raw["order-id"]

        with open("Resoconto.csv", "a", newline = "") as output_file:
            writer = csv.writer(output_file)
            writer.writerow([buyer_name,ship_address,cap,City,province,"1","1","","Fiorentino Service","",note,tel,"","",order_id,""])

def remove_non_ascii(string):
    return "".join(i for i in string if ord(i)<128)

if __name__ == "__main__":
    main()